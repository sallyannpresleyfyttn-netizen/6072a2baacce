// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("in source guard"); }
int main(){
  announce();
  return lionss_run_workload("in-source-guard");
}
