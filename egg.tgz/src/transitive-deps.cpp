// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("transitive deps"); }
int main(){
  announce();
  return lionss_run_workload("transitive-deps");
}
