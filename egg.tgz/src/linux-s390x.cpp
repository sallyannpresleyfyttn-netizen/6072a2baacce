// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("linux s390x\n", stdout);
  return lionss_run_workload("linux-s390x");
}
