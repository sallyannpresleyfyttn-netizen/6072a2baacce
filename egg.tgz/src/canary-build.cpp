// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("canary build"); }
int main(){
  announce();
  return lionss_run_workload("canary-build");
}
